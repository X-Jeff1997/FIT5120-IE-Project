<?php
/**
 * 404 template.
 *
 * @package Hestia
 */

get_header();
do_action( 'hestia_do_404' );
get_footer();
